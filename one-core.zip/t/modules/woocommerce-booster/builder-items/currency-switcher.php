<?php
/**
 * Created by PhpStorm.
 * User: truongsa
 * Date: 8/22/18
 * Time: 14:37
 */

/**
 * Exchange Rate Servers
 *
 * @see https://fixer.io/
 * @see https://currencylayer.com/
 * @see https://openexchangerates.org/ 10 paid
 *
 * @see get_woocommerce_currency
 * @see get_woocommerce_currencies
 *
 */
