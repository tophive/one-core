const purgecss = require('@fullhuman/postcss-purgecss').default;
const cssnano = require('cssnano');

module.exports = {
  plugins: [
    purgecss({
        content: [
            './**/*.php',                    // plugin root
            './**/*.js',
            '../../themes/one/**/*.php'  // optional: your current theme too
        ],
      safelist: {
        standard: [
            /^elementor/,
            /^wp-/,
            /^bp-/,
            'bbp-author-name',
            'bbp-author-avatar img'
        ],
      },
      defaultExtractor: content => content.match(/[\w-/:]+(?<!:)/g) || [],
    }),
    cssnano({ preset: 'default' })
  ],
};
